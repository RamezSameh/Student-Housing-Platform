import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/layout/Navbar";
import Home from "./pages/Home/Home";
import HousingList from "./pages/Housing/HousingList";
import HousingDetails from "./pages/Housing/HousingDetails";
import HousingCompare from "./pages/Housing/HousingCompare";
import Favorites from "./pages/Favorites/Favorites";
import MyBookings from "./pages/Bookings/MyBookings";
import BookingDetails from "./pages/Bookings/BookingDetails";
import RequestBooking from "./pages/Bookings/RequestBooking";


import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Profile from "./pages/Profile";
import Admin from "./pages/Admin";
import AdminDashboard from "./pages/AdminDashboard";
import AdminUsers from "./pages/AdminUsers";

function Placeholder({ title }) {
  return <div className="mx-auto max-w-7xl px-4 py-12"><h1 className="text-3xl font-bold">{title}</h1></div>;
}

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <AuthProvider>
        <main className="min-h-[calc(100vh-64px)] bg-slate-50">


          <Routes>
            {/* <Route path="/" element={<Placeholder title="Sakan Talaba" />} /> */}
            <Route path="/" element={<Home />} />

            <Route
              path="/housing"
              element={<HousingList />}
            />

            <Route
              path="/housing/:id"
              element={<HousingDetails />}
            />

            <Route
              path="/housing/compare"
              element={<HousingCompare />}
            />

            {/* Keep your existing Home/Housing pages here if they already exist. */}

            <Route path="/housing" element={<Placeholder title="Housing" />} />
            <Route path="/housing/:id" element={<Placeholder title="Housing Details" />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route element={<ProtectedRoute />}>
              {/* <Route path="/bookings" element={<Bookings />} /> */}
              <Route path="/bookings" element={<MyBookings />}/>
              <Route path="/profile" element={<Profile />} />
              <Route path="/my-bookings" element={<MyBookings />} />
              <Route path="/favorites" element={<Favorites />}/>
              <Route path="/bookings/:id" element={<BookingDetails />}/>
              <Route path="/bookings/request" element={<RequestBooking />}/>
            </Route>

            <Route element={<ProtectedRoute adminOnly />}>
              <Route path="/admin" element={<Admin />}>
                <Route index element={<AdminDashboard />} />
                <Route path="users" element={<AdminUsers />} />
              </Route>
            </Route>

            <Route path="*" element={<Placeholder title="Page not found" />} />
          </Routes>
        </main>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;