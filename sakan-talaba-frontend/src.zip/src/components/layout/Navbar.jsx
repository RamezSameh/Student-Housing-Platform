import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import {
  Home,
  Heart,
  User,
  CalendarDays,
  Menu,
  X,
} from "lucide-react";

function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] =
    useState(false);

  const navLinkClass = ({ isActive }) =>
    `flex items-center gap-2 font-medium transition ${isActive
      ? "text-blue-600"
      : "text-slate-700 hover:text-blue-600"
    }`;

  const mobileNavLinkClass = ({ isActive }) =>
    `flex items-center gap-3 rounded-xl px-4 py-3 font-medium transition ${isActive
      ? "bg-blue-50 text-blue-600"
      : "text-slate-700 hover:bg-slate-50"
    }`;

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">

      {/* =============================== */}
      {/* Main Navbar */}
      {/* =============================== */}

      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6">

        {/* Logo */}
        <Link
          to="/"
          onClick={closeMobileMenu}
          className="flex shrink-0 items-center gap-2"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white">
            <Home size={22} />
          </div>

          <div>
            <h1 className="text-lg font-bold text-slate-900">
              Sakan Talaba
            </h1>

            <p className="hidden text-xs text-slate-500 sm:block">
              Student Housing
            </p>
          </div>
        </Link>

        {/* =============================== */}
        {/* Desktop Navigation */}
        {/* =============================== */}

        <div className="hidden items-center gap-6 lg:flex">

          <NavLink
            to="/"
            end
            className={navLinkClass}
          >
            Home
          </NavLink>

          <NavLink
            to="/housing"
            className={navLinkClass}
          >
            Find Housing
          </NavLink>

          <NavLink
            to="/universities"
            className={navLinkClass}
          >
            Universities
          </NavLink>

          <NavLink
            to="/my-bookings"
            className={navLinkClass}
          >
            <CalendarDays size={18} />
            My Bookings
          </NavLink>

        </div>

        {/* =============================== */}
        {/* Desktop Actions */}
        {/* =============================== */}

        <div className="hidden items-center gap-2 lg:flex">

          <NavLink
            to="/favorites"
            title="Favorites"
            className={({ isActive }) =>
              `flex items-center gap-2 rounded-lg p-2 transition ${isActive
                ? "bg-red-50 text-red-500"
                : "text-slate-600 hover:bg-slate-100 hover:text-red-500"
              }`
            }
          >
            <Heart size={19} />

            <span className="hidden xl:inline">
              Favorites
            </span>
          </NavLink>

          <Link
            to="/login"
            className="flex items-center gap-2 rounded-lg border border-slate-300 px-3 py-2 font-medium text-slate-700 transition hover:border-blue-600 hover:text-blue-600"
          >
            <User size={18} />

            <span className="hidden xl:inline">
              Login
            </span>
          </Link>

          <Link
            to="/register"
            className="hidden rounded-lg bg-blue-600 px-4 py-2 font-medium text-white transition hover:bg-blue-700 xl:block"
          >
            Register
          </Link>

        </div>

        {/* =============================== */}
        {/* Mobile Menu Button */}
        {/* =============================== */}

        <button
          type="button"
          onClick={() =>
            setMobileMenuOpen(
              (previous) => !previous
            )
          }
          className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-700 transition hover:bg-slate-100 lg:hidden"
          aria-label="Toggle navigation menu"
          aria-expanded={mobileMenuOpen}
        >
          {mobileMenuOpen ? (
            <X size={24} />
          ) : (
            <Menu size={24} />
          )}
        </button>

      </div>

      {/* =============================== */}
      {/* Mobile Navigation */}
      {/* =============================== */}

      {mobileMenuOpen && (
        <div className="border-t border-slate-100 bg-white lg:hidden">

          <div className="mx-auto max-w-7xl space-y-1 px-4 py-4 sm:px-6">

            <NavLink
              to="/"
              end
              onClick={closeMobileMenu}
              className={mobileNavLinkClass}
            >
              <Home size={19} />
              Home
            </NavLink>

            <NavLink
              to="/housing"
              onClick={closeMobileMenu}
              className={mobileNavLinkClass}
            >
              <Home size={19} />
              Find Housing
            </NavLink>

            <NavLink
              to="/universities"
              onClick={closeMobileMenu}
              className={mobileNavLinkClass}
            >
              <Home size={19} />
              Universities
            </NavLink>

            <NavLink
              to="/my-bookings"
              onClick={closeMobileMenu}
              className={mobileNavLinkClass}
            >
              <CalendarDays size={19} />
              My Bookings
            </NavLink>

            <NavLink
              to="/favorites"
              onClick={closeMobileMenu}
              className={mobileNavLinkClass}
            >
              <Heart size={19} />
              Favorites
            </NavLink>

            <div className="my-2 border-t border-slate-100" />

            <Link
              to="/login"
              onClick={closeMobileMenu}
              className="flex items-center gap-3 rounded-xl px-4 py-3 font-medium text-slate-700 transition hover:bg-slate-50"
            >
              <User size={19} />
              Login
            </Link>

            <Link
              to="/register"
              onClick={closeMobileMenu}
              className="flex items-center justify-center rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white transition hover:bg-blue-700"
            >
              Register
            </Link>

          </div>
        </div>
      )}

    </nav>
  );
}

export default Navbar;