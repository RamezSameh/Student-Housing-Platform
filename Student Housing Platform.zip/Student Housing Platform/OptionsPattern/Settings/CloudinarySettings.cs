﻿namespace Student_Housing_Platform.OptionsPattern.Settings
{
    public class CloudinarySettings
    {
        public const string SectionName = "Cloudinary";
        public string CloudName { get; set; } = string.Empty;
        public string ApiKey { get; set; } = string.Empty;
        public string ApiSecret { get; set; } = string.Empty;
    }
}
